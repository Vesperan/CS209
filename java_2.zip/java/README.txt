Lab 2
Andy Ham(aham) and Eri Rogers(emadigan)

When LabTwoGame.java is run, mario will appear, with the animation stopped.
Press 'T' to start the animation, and 'Y' to stop it.
Press 'O' to slow down the animation speed, and 'P' to speed it up
The arrow keys can still move mario's position around and 'W','Q' can still change rotation, so you can press those buttons while the walk animation is running!
