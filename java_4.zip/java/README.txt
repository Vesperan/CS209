Lab 4
Andy Ham (aham) and Eri Rogers (emadigan)

When LabFourGame.java is run, mario will appear along with goomba and peach.
You can move mario using arrow keys and rotate him with 'W' and 'Q'
'A' and 'S' make mario bigger and smaller, and 'Z' and 'X' makes him more or less transparent.
'V' toggles visibility of mario.
'I' 'J' 'K' 'L' moves mario's pivot point around.

The goal is to navigate mario around the goomba and reach peach. If mario's hitbox collides
with goomba's hitbox, he will lose points indicated in the "Score" section on the bottom corner.
If Score reaches 0, you lose the game. If mario reaches peach before score hits 0, you win!




Lab 2
Andy Ham(aham) and Eri Rogers(emadigan)

When LabTwoGame.java is run, mario will appear, with the animation stopped.
Press 'T' to start the animation, and 'Y' to stop it.
Press 'O' to slow down the animation speed, and 'P' to speed it up
The arrow keys can still move mario's position around and 'W','Q' can still change rotation, so you can press those buttons while the walk animation is running!
